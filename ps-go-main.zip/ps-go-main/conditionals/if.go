//if.go start
package main

import (
    "fmt"
)

func main() {
    dddLengthMins := 275 //Docker Deep Dive Course
    cawLengthMins := 30 //Containers on AWS Wavelength course
}
