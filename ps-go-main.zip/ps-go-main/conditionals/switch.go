package main

import (
	"fmt"
)

func main() {

	switch ; {
	case :
	case :
	case :
	case :
	default :
	}

}
