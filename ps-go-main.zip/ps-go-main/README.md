This repo contains most of the source code files for my **Go Fundamentals** course on Pluralsight. 

## About the code files
Most of the time, the file I start with in the video will be just the framework of a program (package delcaration, importing packages, and a main function). You can use this file to follow along with the examples by typing in the code as I show it in the video. A completed version of most code files is also provided with `- COMPLETED` appended to the end of the file name.

## Pull Requests
I only accept PR's to fix mistakes. Thanks in advance.

## Connect with me
I'm happy to connect on any social platform and can usually be found at the **@nigelpoulton** handle. I'm happy to engage, but I cannot provide free or paid technical support -- I'm outrageously busy creating more courses and writing more books and updates.

Enjoy the course!
