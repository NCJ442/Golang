package main

import (
	"fmt"
)

func main() {
	const c = 186000
	fmt.Println("The speed of light is", c, "miles per second")

	c = 488879522821
	fmt.Println("Warp 9 is", c, "miles per hour")
}
